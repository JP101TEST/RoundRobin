import com.mycompany.rr.GUIRR;

public class Main {

	public static void main(String[] args) {
		GUIRR guirr = new GUIRR();
        guirr.main(args);
	}

}
